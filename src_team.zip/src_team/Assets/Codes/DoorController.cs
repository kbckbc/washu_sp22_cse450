using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DoorController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        print("collide to the door, currStage - " + GameController.instance.getStage());
        if (other.gameObject.GetComponent<PlayerController>())
        {
            GotoNextStage(GameController.instance.getStage());
        }
    }
    public void GotoNextStage(int i)
    {
        if (i == 0)
        {
            //GameController.instance.initStage(1);
            GameController.instance.addStage(1);
            SceneManager.LoadScene("Stage2");
        }
        else
        {
            //GameController.instance.initStage(0);
            SceneManager.LoadScene("Stage1");
        }
    }

}
