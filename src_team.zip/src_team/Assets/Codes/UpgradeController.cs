using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class UpgradeController : MonoBehaviour

{
    public static UpgradeController instance;

    //outlets
    public TMP_Text textCoins;
    public TMP_Text maxAmmoTextButton;
    public TMP_Text totalAmmoTextButton;
    public TMP_Text maxAmmoText;
    public TMP_Text totalAmmoText;
    public TMP_Text multiplierText;
    public TMP_Text multiplierTextButton;
    public TMP_Text dashText;
    public TMP_Text dashTextButton;
    public TMP_Text ammoPackText;
    public TMP_Text ammoPackTextButton;


    //state Tracking
    public int coins;
    public int maxAmmo;
    public int totalAmmo;
    public float multiplier;
    public float dash;
    public int ammoPack;


    private void Awake()
    {
        instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        //if (GameController.instance != null && PlayerController.player != null)
        //{
            coins = GameController.instance.coin;
            maxAmmo = PlayerController.player.getMaxAmmo();
            totalAmmo = PlayerController.player.getMaxTotalAmmo();
            multiplier = GameController.instance.bonusMultiplier;
            dash = PlayerController.player.dashCooldown;
            ammoPack = PlayerController.player.ammoPack;
            textCoins.text = "Coins: " + coins.ToString();
            updateText();
        //}
    }

    public void goNextStage()
    {
        GameController.instance.coin = coins;
        GameController.instance.GotoNextStage();
    }

    public void increaseMaxAmmo()
    {
        int cost = maxAmmo * 50;

        if(coins >= cost)
        {
            coins -= cost;
            textCoins.text = "Coins: " + coins.ToString();

            maxAmmo += 5;
            maxAmmoText.text = "Max Ammo: " + maxAmmo.ToString();
            maxAmmoTextButton.text = "+ 5 Max Ammo $" + (maxAmmo * 50).ToString(); 
        }

    }

    public void increaseTotalAmmo()
    {
        int cost = totalAmmo * 10;

        if (coins >= cost)
        {
            coins -= cost;
            textCoins.text = "Coins: " + coins.ToString();

            totalAmmo += 20;
            totalAmmoText.text = "Total Ammo: " + totalAmmo.ToString();
            totalAmmoTextButton.text = "+ 20 Max Ammo $" + (totalAmmo * 10).ToString();
        }

    }

    public void increaseMultiplier()
    {
        int cost = Mathf.RoundToInt(1000 * multiplier);

        if (coins >= cost)
        {
            coins -= cost;
            textCoins.text = "Coins: " + coins.ToString();

            multiplier += 0.5f;
            multiplierText.text = "Multiplier: " + multiplier.ToString()+"x";
            multiplierTextButton.text = "Multiplier $" + (Mathf.RoundToInt(1000 * multiplier)).ToString();
        }
    }

    public void reduceDashCooldown()
    {
        int cost = Mathf.RoundToInt(1000 * (1+(3-dash)));

        if (coins >= cost)
        {
            coins -= cost;
            textCoins.text = "Coins: " + coins.ToString();

            dash -= 0.5f;
            dashText.text = "Cooldown: " + dash.ToString() + "s";
            dashTextButton.text = "Dash Cooldown $" + (Mathf.RoundToInt(1000 * (1 + (3 - dash)))).ToString();
        }
    }

    public void increaseAmmoPack()
    {
        int cost = 1000 + (200 * ((ammoPack / 5)-1));

        if (coins >= cost)
        {
            coins -= cost;
            textCoins.text = "Coins: " + coins.ToString();

            ammoPack += 5;
            ammoPackText.text = "Ammo Pack : " + ammoPack.ToString();
            ammoPackTextButton.text = "+5 Ammo Pack $" + (1000 + (200 * ((ammoPack / 5) - 1))).ToString();
        }
    }

    private void updateText()
    {
        maxAmmoText.text = "Max Ammo: " + maxAmmo.ToString();
        maxAmmoTextButton.text = "+ 5 Max Ammo $" + (maxAmmo * 50).ToString();

        totalAmmoText.text = "Total Ammo: " + totalAmmo.ToString();
        totalAmmoTextButton.text = "+ 20 Max Ammo $" + (totalAmmo * 10).ToString();

        multiplierText.text = "Multiplier: " + multiplier.ToString() + "x";
        multiplierTextButton.text = "Multiplier $" + (Mathf.RoundToInt(1000 * multiplier)).ToString();

        dashText.text = "Cooldown: " + dash.ToString() + "s";
        dashTextButton.text = "Dash Cooldown $" + (Mathf.RoundToInt(1000 * (1 + (3 - dash)))).ToString();

        ammoPackText.text = "Ammo Pack : " + ammoPack.ToString();
        ammoPackTextButton.text = "+5 Ammo Pack $" + (1000 + (200 * ((ammoPack / 5) - 1))).ToString();
    }
}
