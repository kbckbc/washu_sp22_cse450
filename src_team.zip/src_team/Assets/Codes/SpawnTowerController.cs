using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SpawnTowerController : MonoBehaviour
{



    IEnumerator WaitForSceneLoad( GameObject player)
    {
        GameController.instance.clearMonsters();
        
        
        yield return new WaitForSeconds(4);
        
        MenuController.instance.showgameOverScreen();
        Destroy(player);
       
        
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.GetComponent<PlayerController>())
        {
            PlayerController.player.getAnimator().SetBool("Fall",true);
            
           
            PlayerController.player.dead = true;
           
            StartCoroutine(WaitForSceneLoad(other.gameObject));
            
        }
    }


        
     
}
