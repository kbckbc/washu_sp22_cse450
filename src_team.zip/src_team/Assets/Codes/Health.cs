using System;
using UnityEngine;
using UnityEngine.UI;

using System.Collections;

    public class Health : MonoBehaviour
    {
        // Start is called before the first frame update
       // private int health = 1000;
        private static float fullHealth = 100;
       private static float _playerHealth=100;
       public Image healthImage;
       public static Health i;
        
       private void Awake()
       {
           i = this;
       }

       public void damage(int damage)
        {
           
            _playerHealth = _playerHealth - damage;
            EditHealthBar(_playerHealth);
            
        }
        public void eat(int food)
        {
            
            _playerHealth = _playerHealth + food;
            EditHealthBar(_playerHealth);
          
        }
        IEnumerator delay()
        {


            PlayerController.player.dead = true;
            yield return new WaitForSeconds(4);
        
            MenuController.instance.showgameOverScreen();

        }
        public void EditHealthBar(float hp)
        {
            float ratio = hp / fullHealth;
            healthImage.fillAmount = ratio;
            if (hp <= 0)
            {
                PlayerController.player.getAnimator().SetBool("Dead",true);
                
                _playerHealth = 100;
                StartCoroutine(delay());
            }
            if (_playerHealth > 100)
            {
                _playerHealth = 100;
            }
        }


    }



