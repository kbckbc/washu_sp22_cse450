using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuController : MonoBehaviour
{
    // Outlets
    public static MenuController instance;
    public GameObject mainMenu;
    public GameObject howtoScreen;
    public GameObject gameOverScreen;
    public GameObject stageOverScreen;

    private void Awake()
    {
        instance = this;
        Hide();
    }

    public void showgameOverScreen()
    {
        gameOverScreen.SetActive(true);
        
        Time.timeScale = 0;
    }
    
    

    public void restartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void restartGame()
    {
        GameController.instance.restartGame();
    }

    public void Show()
    {
        if (PlayerController.player != null)
        {
            PlayerController.player.isPaused = true;
            mainMenu.SetActive(true);
            Time.timeScale = 0;
        }
    }
    public void Hide()
    {
        if (PlayerController.player != null)
        {
            PlayerController.player.isPaused = false;
        }
        Time.timeScale = 1;
        gameOverScreen.SetActive(false);
        mainMenu.SetActive(false);
        //howtoScreen.SetActive(false);
        stageOverScreen.SetActive(false);
    }

    public void Mute()
    {
        AudioListener.pause = true;
    }

    public void UnMute()
    {
        AudioListener.pause = false;
    }

    public void Howto()
    {
        /*
        mainMenu.transform.localScale = new Vector3(0, 0, 0);
        howtoScreen.SetActive(true);

        centerGameObject(howtoScreen, Camera.main);
        */
    }

    void centerGameObject(GameObject gameOBJToCenter, Camera cameraToCenterOBjectTo, float zOffset = 2.6f)
    {
        gameOBJToCenter.transform.position = cameraToCenterOBjectTo.ViewportToWorldPoint(new Vector3(0.5f, 0.5f, cameraToCenterOBjectTo.nearClipPlane + zOffset));
    }

    // Update is called once per frame
    void Update()
    {
        // For stop
        /*
        if (PlayerController.player != null)
        {
            if (PlayerController.player.isPaused && howtoScreen.activeSelf == true)
            {
                // For menu
                if (Input.anyKey)
                {
                    mainMenu.transform.localScale = new Vector3(1, 1, 1);
                    howtoScreen.SetActive(false);

                }
            }
        }
        */
    }

    public void goToNextStage()
    {
        GameController.instance.GotoNextStage();
    }

    public void goToUpgrades()
    {
        GameController.instance.GoToUpgrade();

    }

    public void showFinish()
    {
        if (PlayerController.player != null)
        {
            PlayerController.player.isPaused = true;
            Time.timeScale = 0;
        }
        stageOverScreen.SetActive(true);
    }
}
