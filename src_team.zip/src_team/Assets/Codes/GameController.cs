using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Random = UnityEngine.Random;


public class GameController : MonoBehaviour
{
    public static GameController instance;



    // outlets
    public GameObject[] monsterPrefabs;
    public Text textStage;
    public Text textCoin;
    public Text textExp;
    public Text textKill;
    public Text textAmmo;
    public GameObject[] foodPrefabs;
    public GameObject Boss;
    public GameObject ammo;
    public GameObject monsterExplosionPrefab;
    public Text stageNum;
    
    public Transform[] foodSpawnPoints;
    public Transform[] monsterSpawnPoints;
    public Transform bossSpawnPoint;

    public int maxFood;
    public int maxMonster;
    public static int foodOnScreen;
    public static int monsterOnScreen;


    // Configuration
    public float minSpawnDelay = 0.2f;
    public float maxSpawnDelay = 2f;

    // State Tracking
    public float timeElpased;
    public float spawnDelay;
    List<GameObject> monsters;
    // Stage setting
    // Adjust this array to move to the next stage quickly
    private int [] killBound = { 10, 25, 999 };
    public int kill;

    // Player's status
    public float bonusMultiplier;
    private static int currStage = 0;
    public int coin;
    private static int exp = 0;

    private bool finalBossShown = false;

    // Methods
    void Awake()
    {
        instance = this;
    }


    void Update()
    {
        // Increment passage of time for each frame of the game
        if (PlayerController.player != null)
        {
            if (PlayerController.player.dead)
            {
                return;
            }

            timeElpased += Time.deltaTime;
            float decreaseDelayOverTime = maxSpawnDelay - ((maxSpawnDelay - minSpawnDelay) / 30f * timeElpased);
            spawnDelay = Mathf.Clamp(decreaseDelayOverTime, minSpawnDelay, maxSpawnDelay);
        }
        UpdateDisplay();

    }

    void SpawnBoss()
    {
        Instantiate(Boss, bossSpawnPoint.position, Quaternion.identity);
    }

    void SpawnMonster()
    {
        if (monsterOnScreen < maxMonster)
        {
            if(currStage == 2)
            {
                // if it is a final, spawn boss only one
                if ( finalBossShown == false)
                {
                    SpawnBoss();
                    finalBossShown = true;
                }
            }
            else if (kill%5==0)
            {
                SpawnBoss();
            }    

            monsterOnScreen++;
            Transform randomSpawnPoint = monsterSpawnPoints[Random.Range(0, monsterSpawnPoints.Length)];
            GameObject randomMonsterPrefab = monsterPrefabs[Random.Range(0, monsterPrefabs.Length)];
            monsters.Add(randomMonsterPrefab);
            Instantiate(randomMonsterPrefab, randomSpawnPoint.position, Quaternion.identity);
        }
    }

    public void removeMonsters(GameObject monster)
    {
        monsters.Remove(monster);
    }

    public void clearMonsters()
    {
        foreach (GameObject monster in monsters)
        {
            Debug.Log(monster);
            //DestroyImmediate(monster.gameObject,true);   
        }
    }
    void SpawnFood()
    {
        int dice = Random.Range(1, 6);
        //Debug.Log(dice);
        if (dice % 2 == 0 && foodOnScreen<maxFood)
        {
            foodOnScreen++;
            Transform randomSpawnPoint = foodSpawnPoints[Random.Range(0, foodSpawnPoints.Length)];
            GameObject food = foodPrefabs[Random.Range(0, foodPrefabs.Length)];

            Instantiate(food, randomSpawnPoint.position, Quaternion.identity);
        }
    }

    public IEnumerator MonsterSpawnTimer()
    {
        // Wait
        yield return new WaitForSeconds(spawnDelay);

        // Spawn
        SpawnMonster();
        SpawnFood();

        // Repeat
        StartCoroutine("MonsterSpawnTimer");
    }
    
    // Made start into IEnumerator to delay start of game. 
    // Let me know if this causes any future problems - Anna
    IEnumerator Start()
    {
        initStage(currStage);
        //if (currStage == 0)
        //this ^ is causing a red error so I changed it to below
        if(SceneManager.GetActiveScene().name == "Stage1")
        {
            GameObject.Find("LoadingScreen").SetActive(true);
            yield return new WaitUntil(readyToStart);
            GameObject.Find("LoadingScreen").SetActive(false);
        }
        initMonster();
    }

    bool readyToStart()
    {
        if (Input.anyKey)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void initStage(int i)
    {
        if (currStage != 0)
        {
            coin = UpgradeController.instance.coins;
            bonusMultiplier = UpgradeController.instance.multiplier;
            print(bonusMultiplier);
        }
        foodOnScreen = 0;
        monsterOnScreen = 0;
        kill = killBound[i];
        stageNum.text = "Stage " + (currStage + 1) + " Clear!";
    }

    public void initMonster()
    {
        StartCoroutine("MonsterSpawnTimer");
        monsters = new List<GameObject>();
    }


    public int getStage()
    {
        return currStage;
    }
    
    public void addStage(int i)
    {
        currStage = currStage + i;
    }
    public void restartGame()
    {
        currStage = 0;
        SceneManager.LoadScene("Stage1");
    }

    public void GotoNextStage()
    {
        print("Stage" + (currStage + 1) + " has been cleared!");
        print("Goto stage" + (currStage + 1) + "!");
        
        if (currStage == 0)
        {
            addStage(1);    
            SceneManager.LoadScene("Stage2");
        }
        else if(currStage == 1)
        {
            addStage(1);
            SceneManager.LoadScene("Stage3");
        }
        else if (currStage == 2)
        {
            addStage(1);
            SceneManager.LoadScene("EndGame");
        }
        else if ( currStage == 3)
        {
            restartGame();
        }
        
    }

    void UpdateDisplay()
    {
        textStage.text = "Stage : " + (currStage+1).ToString();
        textKill.text   = "Kill remain : " + kill.ToString();
        textCoin.text   = "Coin : " + coin.ToString();
        textExp.text    = "Exp  : " + exp.ToString();
        if (PlayerController.player != null)
        {
            int totalAmmo = PlayerController.player.getTotalAmmo();
            if (totalAmmo < 0)
            {
                totalAmmo = 0;
            }

            textAmmo.text = "Ammo : " + PlayerController.player.getAmmo() + " / " +
                            PlayerController.player.getMaxAmmo() + " out of " + totalAmmo;

            if (PlayerController.player.getAmmo() == 0)
            {
                textAmmo.text += " => Reload! Push R!";
            }
        }
    }

    public void EarnPoints(int pointAmount)
    {
        print(bonusMultiplier);
        coin += Mathf.RoundToInt(pointAmount * 10 * bonusMultiplier);
        exp += Mathf.RoundToInt(pointAmount * bonusMultiplier);
        kill -= 1;
    }

    public void GoToUpgrade()
    {
        SceneManager.LoadScene("UpgradeScreen");
    }
}


