using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndPlayerController : MonoBehaviour
{
    // Outlets
    private Animator animator;
    private float start_time;


    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        start_time = Time.time;
    }

    void FixedUpdate()
    {
        animator.Play("Victory");
    }
    private void Update()
    {
        float timeLapse = Time.time - start_time;
        print("timeLapse : " + timeLapse);
        if( timeLapse >= 7)
        {
            GameController.instance.GotoNextStage();
        }
    }
}
