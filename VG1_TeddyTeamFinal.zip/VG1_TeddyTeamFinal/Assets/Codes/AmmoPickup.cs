using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmmoPickup : MonoBehaviour
{
    
    //public Health health;
    public int ammo;
    //private int currentHealth = 100;
    void OnCollisionEnter2D(Collision2D other)
    {
        if (PlayerController.player != null)
        {
            if (other.gameObject.GetComponent<PlayerController>())
            {
                PlayerController.player.setAmmo();
                Destroy(gameObject);
            }
        }
    }
    
}
