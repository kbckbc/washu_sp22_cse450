using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using Random = UnityEngine.Random;

public class MonsterController : MonoBehaviour
{
    // Outlets
    Rigidbody2D _rigidbody;
    private Collider2D _collider;

    private Animator animator;

    private SpriteRenderer spriteRenderer;
    //public int currentHealth = 100;

    // State Tracking
    Transform _target;
    //public Health health;
    public int damagePoints;
    public int _energy;
    private Vector2 movement;
    private float speed = 1f;

    void Awake()
    {
        spriteRenderer = this.GetComponent<SpriteRenderer>();
    }

    // Start is called before the first frame update
    void Start()
    {
        _rigidbody = GetComponent<Rigidbody2D>();
        _target = FindObjectsOfType<PlayerController>()[0].transform;
        animator = GetComponent<Animator>();
        _collider = GetComponent<Collider2D>();
        

    }
    
    private void FixedUpdate()
    {
        if( !this.name.Contains("Bat") && !this.name.Contains("Ghost") ) 
        {
            if (animator)
            {
                animator.SetInteger("Energy", _energy);
            }
        }
    }

    void SpawnAmmo(Vector3 position)
    {
        int randomNum = Random.Range(0, 10);
        if (randomNum % 2 == 0)
        {
            if (GameController.instance != null)
            {
                GameObject ammo = GameController.instance.ammo;
                Instantiate(ammo, position, Quaternion.identity);
            }
        }
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (PlayerController.player != null)
        {
            if (other.gameObject.GetComponent<PlayerController>() && PlayerController.player.dead == false)
            {
                Health.i.damage(damagePoints);

                // push back on collision
                // calculate force vector
                var force = transform.position - other.transform.position;
                // normalize force vector to get direction only and trim magnitude
                force.Normalize();
                other.gameObject.GetComponent<Rigidbody2D>().AddForce(-force * 10f, ForceMode2D.Impulse);
            }

            if (other.gameObject.GetComponent<ProjectileController>())
            {
                _energy--;
                if (_energy == 0)
                {
                    GameController.instance.removeMonsters(gameObject);

                    GameController.instance.EarnPoints(damagePoints);
                    GameController.monsterOnScreen--;
                    SoundManager.instance.PlaySoundHit();
                    SpawnAmmo(transform.position);
                    // Destroy some monsters immediately, allow other monsters time to show death animation
                    if (this.name == "MonsterRed(Clone)" || this.name == "MonsterBat(Clone)" ||
                        this.name == "MonsterGhost(Clone)")
                    {
                        Destroy(gameObject);
                        GameObject explosion = Instantiate(GameController.instance.monsterExplosionPrefab,
                            transform.position, Quaternion.identity);
                        Destroy(explosion, 0.5f);
                    }
                    else
                    {
                        Destroy(_collider);
                        Destroy(gameObject, 1);
                    }

                    if (GameController.instance.kill == 0)
                    {
                        //GameController.instance.GotoNextStage();
                        //GameController.instance.GoToUpgrade();
                        MenuController.instance.showFinish();
                    }

                    if (this.name.Contains("final"))
                    {
                        print("Game finish!");
                        GameController.instance.GotoNextStage();
                    }
                }
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (PlayerController.player != null)
        {
            if (PlayerController.player.dead)
            {
                return;
            }

            if (_target != null && _energy > 0)
            {
                transform.position = Vector2.MoveTowards(transform.position, _target.position, speed * Time.deltaTime);
                if (this.name == "ZombieToast(Clone)" || this.name.Contains("boss"))
                {
                    spriteRenderer.flipX = _target.transform.position.x > transform.position.x;
                }
                else
                {
                    spriteRenderer.flipX = _target.transform.position.x < transform.position.x;
                }
            }

        }
    }

}

