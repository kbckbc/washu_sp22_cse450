using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Outlet
    Rigidbody2D _rigidbody2D;
    public Transform aimPivot;
    public GameObject shootBullet;
    
    SpriteRenderer sprite;
    private Animator animator;
    public int maxAmmo;
    private int currentAmmo;
    public int totalAmmo;
    private int maxTotalAmmo;
    public int ammoPack;
    public static PlayerController player;
    

    // State Tracking
    //public int jumpsLeft;
    private Vector2 lastMoveDir;
    public float dashCooldown;
    private float dashStart = 0f;
    public bool dead;
    public bool upgrade;

    //
    public bool isPaused;
    // Start is called before the first frame update
    void Start()
    {
        _rigidbody2D = GetComponent<Rigidbody2D>();
        sprite = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
        dead = false;
        if (GameController.instance.getStage() != 0)
        {
            maxAmmo = UpgradeController.instance.maxAmmo;
            currentAmmo = maxAmmo;
            maxTotalAmmo = UpgradeController.instance.totalAmmo;
            totalAmmo = maxTotalAmmo;
            dashCooldown = UpgradeController.instance.dash;
            ammoPack = UpgradeController.instance.ammoPack;
        }
        else
        {

            maxAmmo = 15;
            currentAmmo = maxAmmo;
            maxTotalAmmo = 100;
            totalAmmo = maxTotalAmmo;
            dashCooldown = 3;
            ammoPack = 5;
        }

        
        animator.SetBool("Dead", false);
    }
    private void Awake()
    {
        player = this;
    }

    public int getAmmo()
    {
        return currentAmmo;
    }

    public int getMaxAmmo() //in case we add ammo upgrades
    {
        return maxAmmo;
    }

    public void StopRigidBody()
    {
        Destroy(_rigidbody2D);
       
    }

    public int getTotalAmmo()
    {
        return totalAmmo;
    }

    public int getMaxTotalAmmo()
    {
        return maxTotalAmmo;
    }

    public Animator getAnimator()
    {
        return animator;
    }

    public void setAmmo()
    {
        totalAmmo = totalAmmo + ammoPack;
        reload();
    }

    public int setMaxAmmo(int newMax)
    {
        maxAmmo = newMax;
        return maxAmmo;
    }

    public void reloadAmmo()
    {
        totalAmmo = totalAmmo - (maxAmmo - currentAmmo);
    }
   

    void reload()
    {
        reloadAmmo();
        currentAmmo = maxAmmo;
        if (SoundManager.instance != null)
        {
            SoundManager.instance.PlaySoundReload();
        }
    }

    private void FixedUpdate()
    {
        animator.SetFloat("Speed", _rigidbody2D.velocity.magnitude);
        if (_rigidbody2D.velocity.magnitude > 0)
        {
            animator.speed = _rigidbody2D.velocity.magnitude / 3f;
        }
        else
        {
            animator.speed = 1f;
        }
    }


    // Update is called once per frame
    void Update()
    {
        if (dead)
        {
            return;
        }
        // For stop
        if( isPaused )
        {
            return;
        }

        // For menu
        if (Input.GetKey(KeyCode.Escape))
        {
            if (MenuController.instance != null)
            {
                MenuController.instance.Show();
            }
        }
        
        // For keyinputs
        if (Input.GetKey(KeyCode.A))
        {
           
            _rigidbody2D.AddForce(Vector2.left * 12f * Time.deltaTime, ForceMode2D.Impulse);
            sprite.flipX = true;
            lastMoveDir = Vector2.left;
        }
        if (Input.GetKey(KeyCode.D))
        {
            
            _rigidbody2D.AddForce(Vector2.right * 12f * Time.deltaTime, ForceMode2D.Impulse);
            sprite.flipX = false;
            lastMoveDir = Vector2.right;
        }
        if (Input.GetKey(KeyCode.W))
        {
           
            _rigidbody2D.AddForce(Vector2.up * 12f * Time.deltaTime, ForceMode2D.Impulse);
            lastMoveDir = Vector2.up;
        }
        if (Input.GetKey(KeyCode.S))
        {
            
            _rigidbody2D.AddForce(Vector2.down * 12f * Time.deltaTime, ForceMode2D.Impulse);
            lastMoveDir = Vector2.down;
        }

        if (Input.GetKey(KeyCode.R) && totalAmmo>=0)
        {
            reload();
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (Time.time > dashStart + dashCooldown)
            {
                _rigidbody2D.AddForce(lastMoveDir * 15f, ForceMode2D.Impulse);
                dashStart = Time.time;
            }
        }


        // Aim Toward Mouse
        Vector3 mousePosition = Input.mousePosition;
        Vector3 mousePositionInWorld = Camera.main.ScreenToWorldPoint(mousePosition);
        Vector3 directionFromPlayerToMouse = mousePositionInWorld - transform.position;

        float radiansToMouse = Mathf.Atan2(directionFromPlayerToMouse.y, directionFromPlayerToMouse.x);
        float angleToMouse = radiansToMouse * Mathf.Rad2Deg;

        aimPivot.rotation = Quaternion.Euler(0, 0, angleToMouse);

        // Shoot
        if (Input.GetMouseButtonDown(0))
        {
            if (currentAmmo > 0)
            {
                currentAmmo--;
                GameObject newProjectile = Instantiate(shootBullet);
                newProjectile.transform.position = transform.position;
                newProjectile.transform.rotation = aimPivot.rotation;
                
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.name == "Spikes")
        {
            Health.i.damage(10);


            // push back on collision
            // calculate force vector
            var force = other.transform.position - transform.position;
            // normalize force vector to get direction only and trim magnitude
            force.Normalize();
            _rigidbody2D.AddForce(-force * 10f, ForceMode2D.Impulse);
        }
    }
}
