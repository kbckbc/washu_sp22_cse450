using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

public class FoodPickup : MonoBehaviour
{
    
    //public Health health;
    public int foodValue;
    //private int currentHealth = 100;
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.GetComponent<PlayerController>())
        {
            GameController.foodOnScreen--;
            Health.i.eat(foodValue);
            SoundManager.instance.PlaySoundEat();
            Destroy(gameObject);
        }
    }
    
}
