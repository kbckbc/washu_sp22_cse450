using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager instance;

    AudioSource audioSource;
    public AudioClip hitSound;
    public AudioClip reloadSound;
    public AudioClip eatSound;

    private void Awake()
    {
        instance = this;
    }
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void PlaySoundHit()
    {
        audioSource.PlayOneShot(hitSound);
    }

    public void PlaySoundReload()
    {
        audioSource.PlayOneShot(reloadSound);
    }

    public void PlaySoundEat()
    {
        audioSource.PlayOneShot(eatSound);
    }
}
