using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Q5
{
    public class Asteroid : MonoBehaviour
    {
        // outlet
        Rigidbody2D rigidbody;
        float randomSpeed;
        // Start is called before the first frame update
        void Start()
        {
            rigidbody = GetComponent<Rigidbody2D>();
            randomSpeed = Random.Range(0.5f, 3f);
        
        }

        // Update is called once per frame
        void Update()
        {
            rigidbody.velocity = Vector2.left * randomSpeed;
        }

        private void OnBecameInvisible()
        {
            Destroy(gameObject);
        }
    }

}
