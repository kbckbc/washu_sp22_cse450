using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Q5
{
    public class GameController : MonoBehaviour
    {
        public static GameController instance;

        // outlets
        public Transform[] spawnPoints;
        public GameObject[] asteroidPrefabs;
        public GameObject explosionPrefab;
        public Text textScore;
        public Text textMoney;
        public Text missileSpeedUpgradeText;
        public Text bonusUpgradeText;

        // Configuration
        public float minAsteroidDelay = 0.2f;
        public float maxAsteroidDelay = 2f;

        // State Tracking
        public float timeElpased;
        public float asteroidDelay;
        public int score;
        public int money;
        public float missileSpeed = 2f;
        public float bonusMultiplier = 1f;

        public void EarnPoints(int pointAmount)
        {
            score += Mathf.RoundToInt(pointAmount* bonusMultiplier);
            money += Mathf.RoundToInt(pointAmount * bonusMultiplier);
        }

        void UpdateDisplay()
        {
            textScore.text = score.ToString();
            textMoney.text = money.ToString();
        }

        // Methods
        void Awake()
        {
            instance = this;
        }

        public void UpgradeBonus()
        {
            print("UpgradeBonus called!");

            int cost = Mathf.RoundToInt(100 * bonusMultiplier);
            if (cost <= money)
            {
                money -= cost;
                bonusMultiplier += 1f;
                bonusUpgradeText.text = "Multiplier $" + Mathf.RoundToInt(100 * bonusMultiplier).ToString();
            }
        }

        public void UpgradeMissileSpeed()
        {
            print("UpgradeMissileSpeed called!");
            int cost = Mathf.RoundToInt(25 * missileSpeed);
            if(cost <= money) {
                money -= cost;
                missileSpeed += 1f;
                missileSpeedUpgradeText.text = "Missile Speed $" + Mathf.RoundToInt(25 * missileSpeed).ToString();
            }
        }
        void Update()
        {
            // Increment passage of time for each frame of the game
            timeElpased += Time.deltaTime;

            float decreaseDelayOverTime = maxAsteroidDelay - ((maxAsteroidDelay - minAsteroidDelay) / 30f * timeElpased);
            asteroidDelay = Mathf.Clamp(decreaseDelayOverTime, minAsteroidDelay, maxAsteroidDelay);

            UpdateDisplay();
        }

        void SpawnAsteroid()
        {
            Transform randomSpawnPoint = spawnPoints[Random.Range(0, spawnPoints.Length)];
            GameObject randomAsteroidPrefab = asteroidPrefabs[Random.Range(0, asteroidPrefabs.Length)];

            Instantiate(randomAsteroidPrefab, randomSpawnPoint.position, Quaternion.identity);
        }

        IEnumerator AsteroidSpawnTimer()
        {
            // Wait
            yield return new WaitForSeconds(asteroidDelay);

            // Spawn
            SpawnAsteroid();

            // Repeat
            StartCoroutine("AsteroidSpawnTimer");
        }

        void Start()
        {
            StartCoroutine("AsteroidSpawnTimer");

            score = 0;
            money = 0;
        }
    }
}
